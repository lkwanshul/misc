VB Decompiler 9.8 - Unpacked by CrackerJack
===========================================

After some days of hard work, finally, version 9.8 it's here, unpacked :)
Enigma Protector it's a good protector and quite tricky to unpack, but anyway, was funny!

1) Just copy "VB Decompiler.exe" into the installation folder overwriting the original file
2) Enjoy FULL version

